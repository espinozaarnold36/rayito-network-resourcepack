RAYITO NETWORK - ORE PACK
Minecraft Java 1.21.8
Resource pack format: 64

Contenido:
- Minerales vanilla rediseñados en 16x16.
- Alto contraste para reconocerlos rápidamente.
- Acentos eléctricos en los minerales.
- No requiere mods para las texturas.

Bloques incluidos:
carbón, hierro, oro, cobre, diamante, esmeralda, lapislázuli,
redstone, oro del Nether y ancient debris, incluyendo variantes deepslate.

Instalación local:
1. Abre Minecraft Java 1.21.8.
2. Opciones > Paquetes de recursos.
3. Abrir carpeta de paquetes.
4. Copia el ZIP sin descomprimir.
5. Actívalo.

Instalación en servidor:
El ZIP debe estar alojado en una URL HTTPS pública y se configura en server.properties
con resource-pack=<URL> y resource-pack-sha1=<SHA1 del ZIP>.
